## Requisitos

* PHP 8 ou superior
* MySQl 8 ou superior

## Como rodar o projeto baixado

Criar a base de dados "celke".<br>
Alterar as credenciais do banco de dados no arquivo "conexao.php".<br>
Importar o backup do banco de dados, arquivo "celke.sql".

Host: mysql745.umbler.com
BD: celkeprime
Usuário: celkeprime
Senha: iy6IM#9pc8